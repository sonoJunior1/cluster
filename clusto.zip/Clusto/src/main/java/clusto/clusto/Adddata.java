/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clusto.clusto;

import java.io.*;   
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;   
import org.apache.poi.ss.usermodel.Workbook;  
import java.util.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.*;
/**
 *
 * @author souleymane.sono
 */
public class Adddata {
    public static void main(String[] args){
        FileInputStream fis = null;
        try {
            File excelFile = new File("C:\\Users\\Souleymane.Sono\\OneDrive - Playtech\\Documents\\NetBeansProjects\\Clusto\\src\\main\\resources\\schedule.xlsx");
            fis = new FileInputStream(excelFile);
            XSSFWorkbook workbook = new XSSFWorkbook(fis);
            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowInt = sheet.iterator();
            while (rowInt.hasNext()){
                Row row = rowInt.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while(cellIterator.hasNext()){
                    Cell cell = cellIterator.next();
                    System.out.print(cell.toString() + ";");
                    
                }
                System.out.println();
                
                
                
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Adddata.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Adddata.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fis.close();
            } catch (IOException ex) {
                Logger.getLogger(Adddata.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
}
