/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clusto.clusto;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

public class DealerScheduler {

    private static final String INPUT_FILE = "C:\\Users\\Souleymane.Sono\\OneDrive - Playtech\\Documents\\NetBeansProjects\\Clusto\\src\\main\\resources\\data.xlsx";
    private static final String OUTPUT_FILE = "C:\\Users\\Souleymane.Sono\\OneDrive - Playtech\\Documents\\NetBeansProjects\\Clusto\\src\\main\\resources\\schedule.xlsx";

    public void generateSchedule() throws IOException {
        // Load input workbook
        Workbook workbook = new XSSFWorkbook(new FileInputStream(INPUT_FILE));
        Sheet morningSheet = workbook.getSheet("Morning");

        // Load dealer data
        List<Dealer> dealers = loadDealers(morningSheet);

        // Load table priorities
        Sheet tablesSheet = workbook.getSheetAt(3); // Assuming the fourth sheet contains table priorities
        List<String> highPriorityTables = loadTableList(tablesSheet, "High");
        List<String> lowPriorityTables = loadTableList(tablesSheet, "Low");

        // Create schedule workbook
        Workbook scheduleWorkbook = new XSSFWorkbook();
        Sheet scheduleSheet = scheduleWorkbook.createSheet("Schedule");

        // Assign dealers to tables and generate shifts
        assignTables(dealers, highPriorityTables, lowPriorityTables, scheduleSheet);

        // Write the schedule to the output file
        try (FileOutputStream fos = new FileOutputStream(OUTPUT_FILE)) {
            scheduleWorkbook.write(fos);
        }
        scheduleWorkbook.close();
        workbook.close();
    }

    private List<Dealer> loadDealers(Sheet sheet) {
        List<Dealer> dealers = new ArrayList<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) { // Skip the header row
            Row row = sheet.getRow(i);
            String dealerName = row.getCell(1).getStringCellValue(); // Index 1 for dealer name
            boolean draftKing = "Yes".equalsIgnoreCase(row.getCell(2).getStringCellValue());
            boolean qbQualification = "Yes".equalsIgnoreCase(row.getCell(3).getStringCellValue());
            boolean fireQualification = "Yes".equalsIgnoreCase(row.getCell(4).getStringCellValue());
            boolean available = "Yes".equalsIgnoreCase(row.getCell(5).getStringCellValue());
            if (available) {
                dealers.add(new Dealer(dealerName, draftKing, qbQualification, fireQualification));
                System.out.println(dealerName);
            }
        }
        return dealers;
    }

    private List<String> loadTableList(Sheet sheet, String priority) {
        List<String> tables = new ArrayList<>();
        int colIndex = "High".equals(priority) ? 0 : 1;
        for (int i = 1; i <= sheet.getLastRowNum(); i++) { // Skip the header row
            Row row = sheet.getRow(i);
            Cell cell = row.getCell(colIndex);
            if (cell != null && !cell.getStringCellValue().isEmpty()) {
                tables.add(cell.getStringCellValue());
            }
        }
        return tables;
    }

    private void assignTables(List<Dealer> dealers, List<String> highPriority, List<String> lowPriority, Sheet schedule) {
        int rotationCount = 16; // 8 hours shift with 30 minutes per table

        // Create columns for each dealer
        Row headerRow = schedule.createRow(0); // Start from the first row
        for (int i = 0; i < dealers.size(); i++) {
            Dealer dealer = dealers.get(i);
            dealer.setColumnIndex(i);
            Cell headerCell = headerRow.createCell(i + 1); // Start from the second column
            headerCell.setCellValue(dealer.getName());
        }

        // Assign tables
        for (int i = 0; i < rotationCount; i++) {
            Collections.shuffle(highPriority); // Randomize high-priority tables
            Collections.shuffle(lowPriority); // Randomize low-priority tables
            for (Dealer dealer : dealers) {
                if (dealer.isAvailable()) {
                    boolean assigned = false;
                    // Try to assign high-priority tables first
                    for (String table : highPriority) {
                        if (isTableAvailable(schedule, table, i) && dealer.isQualifiedFor(table)) {
                            assignTable(schedule, dealer, table, i);
                            assigned = true;
                            break;
                        }
                    }
                    // If not assigned, try low-priority tables
                    if (!assigned) {
                        for (String table : lowPriority) {
                            if (isTableAvailable(schedule, table, i) && dealer.canWorkLowPriority()) {
                                assignTable(schedule, dealer, table, i);
                                assigned = true;
                                break;
                            }
                        }
                    }
                    // Ensure every dealer is assigned to a table
                    if (!assigned) {
                        for (String table : lowPriority) {
                            if (isTableAvailable(schedule, table, i)) {
                                assignTable(schedule, dealer, table, i);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean isTableAvailable(Sheet schedule, String table, int timeSlot) {
        Row row = schedule.getRow(timeSlot + 1); // Start from the second row
        if (row == null) {
            return true;
        }
        for (Cell cell : row) {
            if (cell.getStringCellValue().equals(table)) {
                return false;
            }
        }
        return true;
    }

    private void assignTable(Sheet schedule, Dealer dealer, String table, int timeSlot) {
        Row row = schedule.getRow(timeSlot + 1); // Start from the second row
        if (row == null) {
            row = schedule.createRow(timeSlot + 1);
        }
        Cell cell = row.createCell(dealer.getColumnIndex() + 1); // Start from the second column
        cell.setCellValue(table);
        dealer.addShift(1); // Add a shift for the dealer
    }

    private boolean isHighPriorityTable(String table, List<String> highPriorityTables) {
        return highPriorityTables.contains(table);
    }

    static class Dealer {
        private final String dealerName;
        private final boolean draftKing;
        private final boolean qbQualification;
        private final boolean fireQualification;
        private int shiftCount;
        private int columnIndex;

        public Dealer(String dealerName, boolean draftKing, boolean qbQualification, boolean fireQualification) {
            this.dealerName = dealerName;
            this.draftKing = draftKing;
            this.qbQualification = qbQualification;
            this.fireQualification = fireQualification;
            this.shiftCount = 0;
        }

        public String getName() {
            return dealerName;
        }

        public boolean isAvailable() {
            return shiftCount < 16; // Assuming a maximum of 16 shifts (30 minutes each) per day
        }

        public boolean isQualifiedFor(String table) {
            if (table.contains("DK") && draftKing) return true;
            if (table.contains("QB") && qbQualification) return true;
            if (table.contains("Fire") && fireQualification) return true;
            return false;
        }

        public boolean canWorkLowPriority() {
            return !draftKing && !qbQualification && !fireQualification;
        }

        public void addShift(int count) {
            this.shiftCount += count;
        }

        public int getShiftCount() {
            return shiftCount;
        }

        public int getColumnIndex() {
            return columnIndex;
        }

        public void setColumnIndex(int columnIndex) {
            this.columnIndex = columnIndex;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Dealer dealer = (Dealer) obj;
            return Objects.equals(dealerName, dealer.dealerName);
        }

        @Override
        public int hashCode() {
            return Objects.hash(dealerName);
        }
    }
}


/*
public class DealerScheduler {

    private static final String INPUT_FILE = "C:\\Users\\Souleymane.Sono\\OneDrive - Playtech\\Documents\\NetBeansProjects\\Clusto\\src\\main\\resources\\data.xlsx";
    private static final String OUTPUT_FILE = "C:\\Users\\Souleymane.Sono\\OneDrive - Playtech\\Documents\\NetBeansProjects\\Clusto\\src\\main\\resources\\schedule.xlsx";

    public void generateSchedule() throws IOException {
        // Load input workbook
        Workbook workbook = new XSSFWorkbook(new FileInputStream(INPUT_FILE));
        Sheet morningSheet = workbook.getSheet("Morning");

        // Load dealer data
        List<Dealer> dealers = loadDealers(morningSheet);

        // Load table priorities
        Sheet tablesSheet = workbook.getSheetAt(3); // Assuming the second sheet contains table priorities
        List<String> highPriorityTables = loadTableList(tablesSheet, "High Priority Tables");
        List<String> lowPriorityTables = loadTableList(tablesSheet, "Low Priority Tables");

        // Create schedule workbook
        Workbook scheduleWorkbook = new XSSFWorkbook();
        Sheet scheduleSheet = scheduleWorkbook.createSheet("Schedule");

        // Assign dealers to tables and generate shifts
        assignTables(dealers, highPriorityTables, lowPriorityTables, scheduleSheet);

        // Write the schedule to the output file
        try (FileOutputStream fos = new FileOutputStream(OUTPUT_FILE)) {
            scheduleWorkbook.write(fos);
        }
        scheduleWorkbook.close();
        workbook.close();
    }

    private List<Dealer> loadDealers(Sheet sheet) {
        List<Dealer> dealers = new ArrayList<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) { // Skip the header row
            Row row = sheet.getRow(i);
            String dealerName = row.getCell(1).getStringCellValue();
            boolean available = "Yes".equalsIgnoreCase(row.getCell(5).getStringCellValue());
            boolean draftKing = "Yes".equalsIgnoreCase(row.getCell(2).getStringCellValue());
            boolean qbQualification = "Yes".equalsIgnoreCase(row.getCell(3).getStringCellValue());
            boolean fbQualification = "Yes".equalsIgnoreCase(row.getCell(4).getStringCellValue());
            if (available) {
                dealers.add(new Dealer(dealerName, draftKing, qbQualification, fbQualification));
                System.out.println(dealerName);
            }
        }
        return dealers;
    }

    private List<String> loadTableList(Sheet sheet, String columnName) {
        List<String> tables = new ArrayList<>();
        int colIndex = "High Priority Tables".equals(columnName) ? 0 : 1;
        for (int i = 1; i <= sheet.getLastRowNum(); i++) { // Skip the header row
            Row row = sheet.getRow(i);
            Cell cell = row.getCell(colIndex);
            if (cell != null && !cell.getStringCellValue().isEmpty()) {
                tables.add(cell.getStringCellValue());
            }
        }
        return tables;
    }

    private void assignTables(List<Dealer> dealers, List<String> highPriority, List<String> lowPriority, Sheet schedule) {
        int dealerIndex = 0;

        // Create columns for each dealer
        Row headerRow = schedule.createRow(1); // Start from the second row
        for (int i = 0; i < dealers.size(); i++) {
            Dealer dealer = dealers.get(i);
            Cell headerCell = headerRow.createCell(i + 1); // Start from the second column
            headerCell.setCellValue(dealer.getName());
        }

        // Assign high-priority tables first
        for (String table : highPriority) {
            dealerIndex = assignTableToDealer(dealers, table, schedule, dealerIndex);
        }

        // Assign low-priority tables next
        for (String table : lowPriority) {
            dealerIndex = assignTableToDealer(dealers, table, schedule, dealerIndex);
        }
    }

    private int assignTableToDealer(List<Dealer> dealers, String table, Sheet schedule, int dealerIndex) {
        Dealer dealer = dealers.get(dealerIndex);

        while (!dealer.isAvailable()) {
            dealerIndex++;
            if (dealerIndex >= dealers.size()) {
                return dealerIndex % dealers.size();
            }
            dealer = dealers.get(dealerIndex);
        }

        if (dealer.isQualifiedFor(table)) {
            // Find the next available row for this dealer
            int rowIndex = 2; // Start from the third row
            while (schedule.getRow(rowIndex) != null && schedule.getRow(rowIndex).getCell(dealerIndex + 1) != null) {
                rowIndex++;
            }
            // Add table assignment to the schedule
            Row row = schedule.getRow(rowIndex);
            if (row == null) {
                row = schedule.createRow(rowIndex);
            }
            Cell cell = row.createCell(dealerIndex + 1); // Start from the second column
            cell.setCellValue(table);
            dealer.addShift(); // Add a shift for the dealer
        }
        return (dealerIndex + 1) % dealers.size();
    }

    static class Dealer {
        private final String dealerName;
        private final boolean draftKing;
        private final boolean qbQualification;
        private final boolean fbQualification;
        private int shiftCount;

        public Dealer(String dealerName, boolean draftKing, boolean qbQualification, boolean fbQualification) {
            this.dealerName = dealerName;
            this.draftKing = draftKing;
            this.qbQualification = qbQualification;
            this.fbQualification = fbQualification;
            this.shiftCount = 0;
        }

        public String getName() {
            return dealerName;
        }

        public boolean isAvailable() {
            return shiftCount < 8; // Assuming a maximum of 8 shifts per day
        }

        public boolean isQualifiedFor(String table) {
            if (table.contains("DK") && draftKing) return true;
            if (table.contains("QB") && qbQualification) return true;
            if (table.contains("FB") && fbQualification) return true;
            return false;
        }

        public void addShift() {
            this.shiftCount++;
        }

        public int getShiftCount() {
            return shiftCount;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Dealer dealer = (Dealer) obj;
            return Objects.equals(dealerName, dealer.dealerName);
        }

        @Override
        public int hashCode() {
            return Objects.hash(dealerName);
        }
    }
    */
