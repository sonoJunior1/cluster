package clusto.clusto;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 *
 * @author souleymane.sono
 */
public class dataRead extends JInternalFrame {
    
    public static void main(String [] args){
        String Filepath = "C:\\Users\\Souleymane.Sono\\OneDrive - Playtech\\Documents\\NetBeansProjects\\Clusto\\src\\main\\resources\\schedule.xlsx";
        dataRead obj = new dataRead();
        //String StdID = obj.readExcel( Filepath, "Dealers", 1, 0);
        //String Firstname = obj.readExcel(Filepath, "Dealers", 1, 3);
        
        //obj.writeExcel( Filepath, "Dealers", 1, 3, "Male");
        //System.out.println(StdID);
        //System.out.println(Firstname);
    }
    
    public void writeExcel(String filePath, String sheetName, String time, String name , String table){
        try{
            String filepath = "C:\\Users\\Souleymane.Sono\\OneDrive - Playtech\\Documents\\NetBeansProjects\\Clusto\\src\\main\\resources\\schedule.xlsx";
            FileInputStream fis = new FileInputStream(filepath);
            Workbook wb = WorkbookFactory.create(fis);
            Sheet s = wb.getSheet(sheetName);
            
            int colNum = -1;
            Row headerRow = s.getRow(0);
            if (headerRow == null) {
                headerRow = s.createRow(0);
            }
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                Cell cell = headerRow.getCell(i);
                if (cell != null && cell.getStringCellValue().equalsIgnoreCase(name)) {
                    colNum = i;
                    break;
                }
            }
            
            // If the dealer name is not found, create a new column
            if (colNum == -1) {
                colNum = headerRow.getLastCellNum();
                if (colNum == -1) {
                    colNum = 1; // Start from column 1 as column 0 is for time
                }
                Cell nameCell = headerRow.createCell(colNum);
                nameCell.setCellValue(name);
            }
            
            // Find the row with the same time
            int rowNum = -1;
            for (int i = 1; i <= s.getLastRowNum(); i++) {
                Row row = s.getRow(i);
                if (row != null) {
                    Cell cell = row.getCell(0); // Assuming the time is in column 0
                    if (cell != null && cell.getStringCellValue().equalsIgnoreCase(time)) {
                        rowNum = i;
                        break;
                    }
                }
            }
            
            // If the time is not found, create a new row
            if (rowNum == -1) {
                rowNum = s.getLastRowNum() + 1;
                Row timeRow = s.createRow(rowNum);
                Cell timeCell = timeRow.createCell(0);
                timeCell.setCellValue(time);
            }
            
            Row r = s.getRow(rowNum);
            if (r == null) {
                r = s.createRow(rowNum);
            }
            // Check if the table is already assigned at this time, excluding "Break"
            if (!table.equalsIgnoreCase("Break")) {
                for (int i = 1; i < r.getLastCellNum(); i++) {
                    Cell cell = r.getCell(i);
                    if (cell != null && cell.getStringCellValue().equalsIgnoreCase(table)) {
                        JOptionPane.showMessageDialog(this, "Table " + table + " is already assigned at " + time, "Error", JOptionPane.ERROR_MESSAGE);
                        wb.close();
                        fis.close();
                        return;
                    }
                }
            }
            // Create different styles for different table categories
            CellStyle loungeBlackjack1Style = createCellStyle(wb, IndexedColors.LIGHT_CORNFLOWER_BLUE, IndexedColors.BLACK);
            CellStyle loungeBlackjack2Style = createCellStyle(wb, IndexedColors.LIGHT_TURQUOISE, IndexedColors.BLACK);
            CellStyle loungeBlackjack3Style = createCellStyle(wb, IndexedColors.LIGHT_YELLOW, IndexedColors.BLACK);
            CellStyle loungeBaccaratStyle = createCellStyle(wb, IndexedColors.LIGHT_GREEN, IndexedColors.BLACK);
            CellStyle sportsCashbackBlackjackStyle = createCellStyle(wb, IndexedColors.LIGHT_ORANGE, IndexedColors.BLACK);
            CellStyle sportsRouletteStyle = createCellStyle(wb, IndexedColors.LIGHT_GREEN, IndexedColors.BLACK);
            CellStyle triviaShowLiveStyle = createCellStyle(wb, IndexedColors.ORANGE, IndexedColors.BLACK);
            CellStyle arcadeBlackjackStyle = createCellStyle(wb, IndexedColors.PINK, IndexedColors.BLACK);
            CellStyle quantumBlackjackStyle = createCellStyle(wb, IndexedColors.VIOLET, IndexedColors.WHITE);
            CellStyle pokerstarsAllBetsBlackjackStyle = createCellStyle(wb, IndexedColors.CORAL, IndexedColors.BLACK);
            CellStyle buffaloBlitzLiveSlotsStyle = createCellStyle(wb, IndexedColors.GOLD, IndexedColors.BLACK);
            CellStyle megaFireBlazeRouletteStyle = createCellStyle(wb, IndexedColors.RED, IndexedColors.WHITE);
            CellStyle draftKingsBlackjack1Style = createCellStyle(wb, IndexedColors.SKY_BLUE, IndexedColors.BLACK);
            CellStyle draftKingsBlackjack2Style = createCellStyle(wb, IndexedColors.LIGHT_BLUE, IndexedColors.BLACK);
            CellStyle draftKingsBlackjack3Style = createCellStyle(wb, IndexedColors.LIGHT_CORNFLOWER_BLUE, IndexedColors.BLACK);
            CellStyle draftKingsBlackjack4Style = createCellStyle(wb, IndexedColors.LIGHT_TURQUOISE, IndexedColors.BLACK);
            CellStyle draftKingsBlackjack5Style = createCellStyle(wb, IndexedColors.LIGHT_YELLOW, IndexedColors.BLACK);
            CellStyle draftKingsBlackjack6Style = createCellStyle(wb, IndexedColors.LIGHT_GREEN, IndexedColors.BLACK);
            CellStyle draftKingsAllBetsBlackjackStyle = createCellStyle(wb, IndexedColors.LIGHT_ORANGE, IndexedColors.BLACK);
            CellStyle draftKingsRouletteStyle = createCellStyle(wb, IndexedColors.LIGHT_GREEN, IndexedColors.BLACK);
            CellStyle breakStyle = createCellStyle(wb, IndexedColors.YELLOW, IndexedColors.BLACK);
            CellStyle defaultStyle = createCellStyle(wb, IndexedColors.WHITE, IndexedColors.BLACK);
            
            // Write the table to the correct cell
            Cell tableCell = r.createCell(colNum);
            tableCell.setCellValue(table);
            
            // Apply style based on the table value
            switch (table) {
                case "Blackjack 1":
                    tableCell.setCellStyle(loungeBlackjack1Style);
                    break;
                case "Blackjack 2":
                    tableCell.setCellStyle(loungeBlackjack2Style);
                    break;
                case "Blackjack 3":
                    tableCell.setCellStyle(loungeBlackjack3Style);
                    break;
                case "Baccarat":
                    tableCell.setCellStyle(loungeBaccaratStyle);
                    break;
                case "Cashback":
                    tableCell.setCellStyle(sportsCashbackBlackjackStyle);
                    break;
                case "Sports Roulette":
                    tableCell.setCellStyle(sportsRouletteStyle);
                    break;
                case "Trivia":
                    tableCell.setCellStyle(triviaShowLiveStyle);
                    break;
                case "Arcade Blackjack":
                    tableCell.setCellStyle(arcadeBlackjackStyle);
                    break;
                case "Quantum Blackjack":
                    tableCell.setCellStyle(quantumBlackjackStyle);
                    break;
                case "All Bets Blackjack":
                    tableCell.setCellStyle(pokerstarsAllBetsBlackjackStyle);
                    break;
                case "Buffalo Blitz":
                    tableCell.setCellStyle(buffaloBlitzLiveSlotsStyle);
                    break;
                case "Fire Blaze":
                    tableCell.setCellStyle(megaFireBlazeRouletteStyle);
                    break;
                case "DK Blackjack 1":
                    tableCell.setCellStyle(draftKingsBlackjack1Style);
                    break;
                case "DK Blackjack 2":
                    tableCell.setCellStyle(draftKingsBlackjack2Style);
                    break;
                case "DK Blackjack 3":
                    tableCell.setCellStyle(draftKingsBlackjack3Style);
                    break;
                case "DraftKings Blackjack 4":
                    tableCell.setCellStyle(draftKingsBlackjack4Style);
                    break;
                case "DK Blackjack 5":
                    tableCell.setCellStyle(draftKingsBlackjack5Style);
                    break;
                case "DK Blackjack 6":
                    tableCell.setCellStyle(draftKingsBlackjack6Style);
                    break;
                case "DK All Bets":
                    tableCell.setCellStyle(draftKingsAllBetsBlackjackStyle);
                    break;
                case "DK Roulette":
                    tableCell.setCellStyle(draftKingsRouletteStyle);
                    break;
                case "Break":
                    tableCell.setCellStyle( breakStyle);
                default:
                    tableCell.setCellStyle(defaultStyle);
                    break;
            }
            
            FileOutputStream fos = new FileOutputStream(filePath);
            wb.write(fos);
            fos.close();
            wb.close();
            fis.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private CellStyle createCellStyle(Workbook wb, IndexedColors bgColor, IndexedColors fontColor) {
        CellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(bgColor.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        Font font = wb.createFont();
        font.setColor(fontColor.getIndex());
        style.setFont(font);
        return style;
    }
    

}
