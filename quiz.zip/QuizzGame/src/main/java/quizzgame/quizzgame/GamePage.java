
package quizzgame.quizzgame;

import java.awt.Color;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
/**
 *
 * @author souleymane.sono
 */
public class GamePage extends javax.swing.JFrame {
    private int questionIndex = 1;
    private int score = 0;
    private Timer timer;
    private Map<Integer, Question> questions;
    private String playerName;
    private int numCorrectAnswers = 0;
    private int numWrongAnswers = 0;
    private int currentScore = 0;

    /**
     * Creates new form GamePage
     */
    public GamePage() {
        initComponents();
        questions = NetworkQuestions.getQuestions();
        setupQuiz();
    }
    
    
    private void setupQuiz() {
            Start.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startQuiz();
            }
        });

            timer = new Timer(2000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nextQuestion();
                }
            });

            Option1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    checkAnswer(Option1, 0);
                }
            });

            Option2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    checkAnswer(Option2, 1);
                }
            });

            Option3.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    checkAnswer(Option3, 2);
                }
            });

            Option4.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    checkAnswer(Option4, 3);
                }
            });
    }

    private void showQuestion() {
        if (questionIndex > questions.size()) {
        endQuiz();
        Start.setEnabled(true);
        return;
    
        }
        Question question = questions.get(questionIndex);
        Question.setText(question.getQuestion());
        Option1.setText(question.getOptions()[0]);
        Option2.setText(question.getOptions()[1]);
        Option3.setText(question.getOptions()[2]);
        Option4.setText(question.getOptions()[3]);

        // Reset button states
        Option1.setEnabled(true);
        Option2.setEnabled(true);
        Option3.setEnabled(true);
        Option4.setEnabled(true);
        Option1.setBackground(Color.WHITE);
        Option2.setBackground(Color.WHITE);
        Option3.setBackground(Color.WHITE);
        Option4.setBackground(Color.WHITE);
    
    }
        
    private void nextQuestion() {
        questionIndex++;
        showQuestion();
    }

    private void startQuiz() {
        playerName = JOptionPane.showInputDialog(this, "Enter your username:");
        if (playerName == null || playerName.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username cannot be empty. Please enter a valid username.");
            return;
        }
        player.setText(playerName);
        Start.setVisible(false);
        showQuestion();
        timer.start();
    }
    

    private void endQuiz() {
        timer.stop();
        //JOptionPane.showMessageDialog(this, "Quiz Finished! Your score is: " + score);
        TotalScore1.setText(String.valueOf(score));
        Start.setEnabled(true);
       
    }
    
    private void checkAnswer(JButton selectedButton, int optionIndex) {
        Question question = questions.get(questionIndex);
        String selectedOption = question.getOptions()[optionIndex];
        String correctAnswer = question.getAnswer();

        // Extract the letter from the selected option
        String selectedLetter = selectedOption.substring(0, selectedOption.indexOf(')')).trim();

        //System.out.println("Selected Option: " + selectedOption);
        //System.out.println("Selected Letter: " + selectedLetter);
        //System.out.println("Correct Answer: " + correctAnswer);

        // Disable all buttons except the selected one
        Option1.setEnabled(false);
        Option2.setEnabled(false);
        Option3.setEnabled(false);
        Option4.setEnabled(false);
        selectedButton.setEnabled(true);

        if (selectedLetter.equals(correctAnswer)) {
            selectedButton.setBackground(Color.GREEN);
            numCorrectAnswers++;
            currentScore += 10; // Assuming each correct answer gives 10 points
            
        } else {
            selectedButton.setBackground(Color.RED);
            numWrongAnswers++;
        }
        score = currentScore;
        // Update the score display (if you have a JLabel for the score)
        //jLabel3.setText("Score: " + currentScore);
        current.setText(String.valueOf(currentScore));
        correct.setText(String.valueOf(numCorrectAnswers));
        wrong.setText(String.valueOf(numWrongAnswers));
    
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Question = new javax.swing.JLabel();
        Option1 = new javax.swing.JButton();
        Option2 = new javax.swing.JButton();
        Option3 = new javax.swing.JButton();
        Option4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Exit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Start = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        player = new javax.swing.JLabel();
        wrong = new javax.swing.JLabel();
        current = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        TotalScore1 = new javax.swing.JLabel();
        correct = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 0, 102));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 0), 3, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Question.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 25)); // NOI18N
        Question.setForeground(new java.awt.Color(255, 255, 255));
        Question.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Question.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jPanel1.add(Question, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 334, 782, 97));

        Option1.setFont(new java.awt.Font("Lucida Console", 1, 18)); // NOI18N
        jPanel1.add(Option1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 588, 351, 73));

        Option2.setFont(new java.awt.Font("Lucida Console", 1, 18)); // NOI18N
        jPanel1.add(Option2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 488, 351, 73));

        Option3.setFont(new java.awt.Font("Lucida Console", 1, 18)); // NOI18N
        jPanel1.add(Option3, new org.netbeans.lib.awtextra.AbsoluteConstraints(441, 488, 351, 73));

        Option4.setFont(new java.awt.Font("Lucida Console", 1, 18)); // NOI18N
        jPanel1.add(Option4, new org.netbeans.lib.awtextra.AbsoluteConstraints(441, 588, 351, 73));

        jLabel2.setFont(new java.awt.Font("Edwardian Script ITC", 1, 100)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 204, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Quizz Game ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 15, 773, 140));

        Exit.setBackground(new java.awt.Color(204, 0, 51));
        Exit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Exit.setForeground(new java.awt.Color(255, 255, 255));
        Exit.setText("Exit");
        jPanel1.add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(477, 732, 173, 41));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Total Score");
        jLabel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 0), 2, true));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 390, 320, 40));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 204, 0));
        jLabel4.setText("player:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 70, 130, 40));

        Start.setBackground(new java.awt.Color(51, 204, 0));
        Start.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Start.setForeground(new java.awt.Color(255, 255, 255));
        Start.setText("Start");
        jPanel1.add(Start, new org.netbeans.lib.awtextra.AbsoluteConstraints(159, 737, 173, 41));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 204, 0));
        jLabel5.setText("Correct Answer:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 120, 170, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 204, 0));
        jLabel6.setText("Wrong Answer:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 170, 170, 40));

        player.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        player.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(player, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 70, 170, 40));

        wrong.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        wrong.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(wrong, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 170, 120, 40));

        current.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        current.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(current, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 220, 120, 40));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 204, 0));
        jLabel8.setText("Current Score:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 220, 170, 40));

        TotalScore1.setFont(new java.awt.Font("Segoe UI", 1, 70)); // NOI18N
        TotalScore1.setForeground(new java.awt.Color(255, 204, 0));
        TotalScore1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TotalScore1.setText("0");
        jPanel1.add(TotalScore1, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 500, 310, 150));

        correct.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        correct.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(correct, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 120, 120, 40));

        jLabel3.setFont(new java.awt.Font("Lucida Console", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Score Board", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24), new java.awt.Color(255, 204, 0))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(826, 6, 347, 767));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1197, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 867, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GamePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Exit;
    private javax.swing.JButton Option1;
    private javax.swing.JButton Option2;
    private javax.swing.JButton Option3;
    private javax.swing.JButton Option4;
    private javax.swing.JLabel Question;
    private javax.swing.JButton Start;
    private javax.swing.JLabel TotalScore1;
    private javax.swing.JLabel correct;
    private javax.swing.JLabel current;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel player;
    private javax.swing.JLabel wrong;
    // End of variables declaration//GEN-END:variables
}
