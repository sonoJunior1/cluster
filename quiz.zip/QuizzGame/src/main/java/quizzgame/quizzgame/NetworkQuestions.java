
package quizzgame.quizzgame;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author souleymane.sono
 */
public class NetworkQuestions {
    public static Map<Integer, Question> getQuestions() {
        Map<Integer, Question> questions = new HashMap<>();
        questions.put(1, new Question("What is a computer network?", new String[]{"a) A single computer", "b) A collection of interconnected computers", "c) A software application", "d) A type of computer virus"}, "b"));
        questions.put(2, new Question("Which device is used to connect multiple networks together?", new String[]{"a) Switch", "b) Router", "c) Hub", "d) Modem"}, "b"));
        questions.put(3, new Question("What does LAN stand for?", new String[]{"a) Large Area Network", "b) Local Area Network", "c) Long Area Network", "d) Light Area Network"}, "b"));
        questions.put(4, new Question("Which protocol is used to transfer files over the Internet?", new String[]{"a) HTTP", "b) FTP", "c) SMTP", "d) SNMP"}, "b"));
        questions.put(5, new Question("What is the main function of a firewall?", new String[]{"a) To connect different networks", "b) To prevent unauthorized access", "c) To store data", "d) To manage network traffic"}, "b"));
        questions.put(6, new Question("Which topology has a central hub to which all nodes are connected?", new String[]{"a) Bus", "b) Star", "c) Ring", "d) Mesh"}, "b"));
        questions.put(7, new Question("What does IP stand for in IP address?", new String[]{"a) Internet Protocol", "b) Internal Protocol", "c) Internet Program", "d) Internal Program"}, "a"));
        questions.put(8, new Question("Which layer of the OSI model is responsible for data encryption?", new String[]{"a) Physical layer", "b) Data link layer", "c) Network layer", "d) Presentation layer"}, "d"));
        questions.put(9, new Question("What is the purpose of a subnet mask?", new String[]{"a) To identify the network portion of an IP address", "b) To encrypt data", "c) To connect different networks", "d) To manage network traffic"}, "a"));
        questions.put(10, new Question("Which of the following is a wireless networking technology?", new String[]{"a) Ethernet", "b) Wi-Fi", "c) Token Ring", "d) Fiber Optics"}, "b"));
        return questions;
    }
    
}
