/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package quizzgame.quizzgame;

/**
 *
 * @author souleymane.sono
 */
public class QuizzGame {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
